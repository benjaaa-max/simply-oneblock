scoreboard players add #wave so_ar 1
execute store result bossbar so_arenas:fight value run scoreboard players get #wave so_ar
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"zombie",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"husk",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"skeleton",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"spider",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"skeleton",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"zombie_armor",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"piglin",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"bogged",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"cave_spider",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"witch",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"vindicator",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"pillager",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"witch",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"drowned_trident",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"spider_big",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"zombie_ominous",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"breeze",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"bogged",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"enderman",t:0}
execute if score #wave so_ar matches 1.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"wither_skeleton",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"zombie",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"husk",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"skeleton",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"spider",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"skeleton",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"zombie_armor",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"piglin",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"bogged",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"cave_spider",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"witch",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"vindicator",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"pillager",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"witch",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"drowned_trident",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"spider_big",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"zombie_ominous",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"breeze",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"bogged",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"enderman",t:0}
execute if score #wave so_ar matches 2.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"wither_skeleton",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"zombie",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"husk",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"skeleton",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"spider",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 0.. unless score #blk so_ar matches 3334.. run function so_arenas:lib/spawn {m:"skeleton",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"zombie_armor",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"piglin",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"bogged",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"cave_spider",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 3334.. unless score #blk so_ar matches 7501.. run function so_arenas:lib/spawn {m:"witch",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"vindicator",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"pillager",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"witch",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"drowned_trident",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 7501.. unless score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"spider_big",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"zombie_ominous",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"breeze",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"bogged",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"enderman",t:0}
execute if score #wave so_ar matches 3.. if score #blk so_ar matches 15000.. run function so_arenas:lib/spawn {m:"wither_skeleton",t:0}
execute as @a[tag=so_ar_in] at @s run playsound minecraft:event.raid.horn master @s ~ ~ ~ 0.6 1.0
