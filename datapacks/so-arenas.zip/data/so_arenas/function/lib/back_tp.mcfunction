$execute in minecraft:overworld run tp @s $(x) $(y) $(z)
