playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 1 0.8
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.2
effect give @s minecraft:slow_falling 15 0 true
title @s times 10 40 10
title @s subtitle [{"text":"La Boveda Cosmica","color":"light_purple","italic":true}]
title @s title [{"text":"✦ EL VACIO ✦","color":"aqua","bold":true}]
execute in so_arenas:vacio run setblock 0 99 0 minecraft:bedrock
execute in so_arenas:vacio run setblock 1 99 0 minecraft:bedrock
execute in so_arenas:vacio run setblock -1 99 0 minecraft:bedrock
execute in so_arenas:vacio run setblock 0 99 1 minecraft:bedrock
execute in so_arenas:vacio run setblock 0 99 -1 minecraft:bedrock
execute in so_arenas:vacio run tp @s 0.5 100 0.5 0 0
execute as @s[gamemode=survival] run gamemode adventure @s
tellraw @s [{"text":"[Portal] ","color":"gold"},{"text":"Has entrado al Vacio. Para volver usa: ","color":"gray"},{"text":"/function so_arenas:portal/return_lobby","color":"yellow","underlined":true}]
