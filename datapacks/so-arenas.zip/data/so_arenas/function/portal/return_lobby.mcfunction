# Teletransporta al jugador de vuelta frente a los portales del Lobby en Overworld
execute at @e[tag=so_lobby_anchor,limit=1] run tp @s ~10 ~1 ~20 90 0
execute unless entity @e[tag=so_lobby_anchor] in minecraft:overworld run tp @s 0 100 0
tellraw @s [{"text":"[Portal] ","color":"gold"},{"text":"Regresaste al Lobby del Overworld.","color":"green"}]
