execute at @e[tag=so_lobby_anchor,limit=1] run tp @s ~ ~1 ~ 0 0
execute unless entity @e[tag=so_lobby_anchor] in minecraft:overworld run tp @s 0 100 0
tellraw @s [{"text":"[Portal] ","color":"gold"},{"text":"Regresaste al Lobby del Overworld.","color":"green"}]
