playsound minecraft:entity.blaze.ambient player @s ~ ~ ~ 1 0.8
playsound minecraft:block.portal.travel player @s ~ ~ ~ 0.7 1.0
effect give @s minecraft:fire_resistance 30 0 true
title @s times 10 40 10
title @s subtitle [{"text":"Reino del Fuego Eterno","color":"gold","italic":true}]
title @s title [{"text":"🔥 PURGATORIO 🔥","color":"red","bold":true}]
execute in so_arenas:purgatorio run tp @s 0.5 100 0.5 0 0
execute as @s[gamemode=survival] run gamemode adventure @s
tellraw @s [{"text":"[Portal] ","color":"gold"},{"text":"Has cruzado al Purgatorio. Para volver usa ","color":"gray"},{"text":"/trigger volver","color":"yellow","bold":true}]
