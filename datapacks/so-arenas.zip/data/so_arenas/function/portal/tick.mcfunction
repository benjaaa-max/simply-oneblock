# Particulas y deteccion en Portal 1: Criptas
execute at @e[tag=so_portal_criptas] run particle soul_fire_flame ~ ~ ~ 0.2 3.0 2.0 0.01 6
execute at @e[tag=so_portal_criptas] run particle sculk_soul ~ ~ ~ 0.1 2.5 1.5 0.01 2
execute at @e[tag=so_portal_criptas] as @a[distance=..2.4] at @s run function so_arenas:portal/enter_criptas

# Particulas y deteccion en Portal 2: Purgatorio
execute at @e[tag=so_portal_purgatorio] run particle flame ~ ~ ~ 0.2 3.0 2.0 0.02 8
execute at @e[tag=so_portal_purgatorio] run particle lava ~ ~ ~ 0.1 2.0 1.5 0.01 3
execute at @e[tag=so_portal_purgatorio] as @a[distance=..2.4] at @s run function so_arenas:portal/enter_purgatorio

# Particulas y deteccion en Portal 3: Vacio
execute at @e[tag=so_portal_vacio] run particle portal ~ ~ ~ 0.3 3.0 2.0 0.5 25
execute at @e[tag=so_portal_vacio] run particle end_rod ~ ~ ~ 0.1 2.5 1.5 0.02 3
execute at @e[tag=so_portal_vacio] as @a[distance=..2.4] at @s run function so_arenas:portal/enter_vacio

# Reglas continuas en las dimensiones
function so_arenas:portal/dim_rules
