playsound minecraft:entity.warden.heartbeat player @s ~ ~ ~ 1 0.7
playsound minecraft:ambient.cave player @s ~ ~ ~ 1 0.9
effect give @s minecraft:darkness 3 0 true
title @s times 10 40 10
title @s subtitle [{"text":"Reino de las Criptas Olvidadas","color":"dark_purple","italic":true}]
title @s title [{"text":"⚰ CRIPTAS ⚰","color":"dark_red","bold":true}]
execute in so_arenas:criptas run setblock 0 99 0 minecraft:bedrock
execute in so_arenas:criptas run setblock 1 99 0 minecraft:bedrock
execute in so_arenas:criptas run setblock -1 99 0 minecraft:bedrock
execute in so_arenas:criptas run setblock 0 99 1 minecraft:bedrock
execute in so_arenas:criptas run setblock 0 99 -1 minecraft:bedrock
execute in so_arenas:criptas run tp @s 0.5 100 0.5 0 0
execute as @s[gamemode=survival] run gamemode adventure @s
tellraw @s [{"text":"[Portal] ","color":"gold"},{"text":"Has entrado al Reino de las Criptas. Para volver usa: ","color":"gray"},{"text":"/function so_arenas:portal/return_lobby","color":"yellow","underlined":true}]
