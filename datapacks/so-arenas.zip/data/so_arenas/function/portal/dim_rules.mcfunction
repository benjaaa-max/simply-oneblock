# Clima tormentoso continuo en Criptas
execute in so_arenas:criptas run weather thunder 1000000
# Forzar aventura en las 3 dimensiones para jugadores que no estan en creativo o espectador
execute as @a[gamemode=survival] if dimension so_arenas:criptas run gamemode adventure @s
execute as @a[gamemode=survival] if dimension so_arenas:purgatorio run gamemode adventure @s
execute as @a[gamemode=survival] if dimension so_arenas:vacio run gamemode adventure @s
# Limpieza de mobs naturales
execute in so_arenas:criptas run kill @e[type=!player,type=!item_frame,type=!interaction,type=!text_display,type=!marker,type=!armor_stand,type=!villager,tag=!so_safe]
execute in so_arenas:purgatorio run kill @e[type=!player,type=!item_frame,type=!interaction,type=!text_display,type=!marker,type=!armor_stand,type=!villager,tag=!so_safe]
execute in so_arenas:vacio run kill @e[type=!player,type=!item_frame,type=!interaction,type=!text_display,type=!marker,type=!armor_stand,type=!villager,tag=!so_safe]
