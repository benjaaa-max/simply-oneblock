# Clima tormentoso continuo en Criptas
execute in so_arenas:criptas run weather thunder 1000000
execute in so_arenas:criptas run time set 18000
# Forzar aventura en las 3 dimensiones si esta en survival
execute as @a[gamemode=survival] if dimension so_arenas:criptas run gamemode adventure @s
execute as @a[gamemode=survival] if dimension so_arenas:purgatorio run gamemode adventure @s
execute as @a[gamemode=survival] if dimension so_arenas:vacio run gamemode adventure @s
