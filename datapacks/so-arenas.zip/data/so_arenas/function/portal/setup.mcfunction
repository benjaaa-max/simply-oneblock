# Coloca la estructura catacumbs_lobby en la posicion actual
execute at @s run place structure so_arenas:catacumbs_lobby ~ ~ ~
# Limpia marcadores anteriores en un radio de 50 bloques
execute at @s run kill @e[tag=so_portal_marker,distance=..60]
# Genera el ancla del lobby
execute at @s run summon marker ~ ~ ~ {Tags:["so_portal_marker","so_lobby_anchor"]}
# Portal 1 (Criptas): Z=8.5, Y=5.5, X=1.5 relativo a la esquina de la estructura
execute at @s run summon marker ~1.5 ~5.5 ~8.5 {Tags:["so_portal_marker","so_portal_criptas"]}
# Portal 2 (Purgatorio): Z=20.5, Y=5.5, X=1.5
execute at @s run summon marker ~1.5 ~5.5 ~20.5 {Tags:["so_portal_marker","so_portal_purgatorio"]}
# Portal 3 (Vacio): Z=32.5, Y=5.5, X=1.5
execute at @s run summon marker ~1.5 ~5.5 ~32.5 {Tags:["so_portal_marker","so_portal_vacio"]}
# Crea plataformas seguras temporales de llegada (3x3) en cada dimension en 0 100 0
execute in so_arenas:criptas run fill -1 99 -1 1 99 1 minecraft:polished_deepslate
execute in so_arenas:criptas run setblock 0 100 0 minecraft:light[level=15]
execute in so_arenas:purgatorio run fill -1 99 -1 1 99 1 minecraft:nether_bricks
execute in so_arenas:purgatorio run setblock 0 100 0 minecraft:light[level=15]
execute in so_arenas:vacio run fill -1 99 -1 1 99 1 minecraft:end_stone_bricks
execute in so_arenas:vacio run setblock 0 100 0 minecraft:light[level=15]
tellraw @s [{"text":"[Megadungeons] ","color":"gold","bold":true},{"text":"¡Lobby de Catacumbas y 3 Portales Dimensionales activados con exito!","color":"green"}]
