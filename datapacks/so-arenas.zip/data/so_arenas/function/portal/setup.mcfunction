# Centra la estructura catacumbs_lobby en la posicion actual (~-20 ~-1 ~-20)
execute at @s run place structure so_arenas:catacumbs_lobby ~-20 ~-1 ~-20

# Limpia marcadores anteriores
execute at @s run kill @e[tag=so_portal_marker,distance=..60]

# Genera ancla central del lobby
execute at @s run summon marker ~ ~ ~ {Tags:["so_portal_marker","so_lobby_anchor"]}

# Portal 1 (Criptas): relativo a la esquina de la estructura (X=1, Z=8, Y=5.5) -> relativo al centro: ~-19 ~4.5 ~-12
execute at @s run summon marker ~-19 ~4.5 ~-12 {Tags:["so_portal_marker","so_portal_criptas"]}

# Portal 2 (Purgatorio): relativo a la esquina (X=1, Z=20, Y=5.5) -> relativo al centro: ~-19 ~4.5 ~0
execute at @s run summon marker ~-19 ~4.5 ~0 {Tags:["so_portal_marker","so_portal_purgatorio"]}

# Portal 3 (Vacio): relativo a la esquina (X=1, Z=32, Y=5.5) -> relativo al centro: ~-19 ~4.5 ~12
execute at @s run summon marker ~-19 ~4.5 ~12 {Tags:["so_portal_marker","so_portal_vacio"]}

tellraw @s [{"text":"[so_arenas] ","color":"gold"},{"text":"Estructura del Lobby y los 3 Portales configurados correctamente.","color":"green"}]
