# Tick de Megadungeons: Portales y Reglas de Dimension
function so_arenas:portal/tick
function so_arenas:portal/dim_rules
