tellraw @s [{"text":"[Test] ","color":"gold"},{"text":"Probando dimensiones...","color":"yellow"}]
execute in so_arenas:criptas run tp @s 0 100 0
