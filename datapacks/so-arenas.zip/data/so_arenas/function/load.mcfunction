scoreboard objectives add so_portal_cd dummy
tellraw @a [{"text":"[Megadungeons] ","color":"gold","bold":true},{"text":"Dimensiones y Portales cargados correctamente. Usa ","color":"green"},{"text":"/function so_arenas:portal/setup","color":"yellow","bold":true},{"text":" donde quieras colocar tu Lobby.","color":"green"}]
